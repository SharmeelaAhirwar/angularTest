import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ShipmentModelsModule } from '../models/shipment-models/shipment-models.module';

@Injectable({
  providedIn: 'root'
})
export class ShipmentServicesService {

  constructor(private http:HttpClient) {}

    getShipmentResult():Observable<ShipmentModelsModule>{
      return this.http.get<ShipmentModelsModule>('http://localhost:3000/Shipments')
      
    }

  

}
