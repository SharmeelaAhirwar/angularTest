import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipment-summary',
  templateUrl: './shipment-summary.component.html',
  styleUrls: ['./shipment-summary.component.css']
})
export class ShipmentSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
